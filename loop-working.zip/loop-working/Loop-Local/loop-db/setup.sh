#!/bin/bash

mypath=`realpath $0`
mybase=`dirname $mypath`

dbname=loop

if [[ -n `psql -lqt | cut -d \| -f 1 | grep -w "$dbname"` ]]; then
    dropdb $dbname
fi
createdb $dbname

cd $mybase
psql -af create-table-base.sql $dbname
psql -af load-table-new.sql $dbname
