CREATE TABLE RegisteredUser
(id VARCHAR(256) NOT NULL PRIMARY KEY,
name VARCHAR(256) NOT NULL,
password VARCHAR(256) NOT NULL);

CREATE TABLE RegisteredGroup
(gid VARCHAR(256) NOT NULL PRIMARY KEY,
group_name VARCHAR(256) NOT NULL);

CREATE TABLE isMemberOf
(id VARCHAR(256) NOT NULL
REFERENCES RegisteredUser(id),
gid VARCHAR(256) NOT NULL
References RegisteredGroup(gid),
PRIMARY KEY(id, gid));

CREATE TABLE AllEvents
(eid VARCHAR(256) NOT NULL UNIQUE,
gid VARCHAR(256) NOT NULL REFERENCES RegisteredGroup(gid),
id VARCHAR(256) NOT NULL REFERENCES RegisteredUser(id),
event_name CHAR(100) NOT NULL,
event_location CHAR(100),
event_date date,
    CHECK(event_date >= current_date or event_date is NULL),
event_start_time time,
event_end_time time,
CHECK(event_end_time >= event_start_time or event_end_time is NULL),
---need to add timezone functionality at some point
event_description CHAR(500),
event_cost DECIMAL(10, 2),
	CHECK(event_cost >= 0.0),
tstz timestamptz,
	PRIMARY KEY(eid, gid));

CREATE TABLE RSVPto
(id VARCHAR(256) NOT NULL REFERENCES RegisteredUser(id),
eid VARCHAR(256) NOT NULL REFERENCES AllEvents(eid),
gid VARCHAR(256) NOT NULL REFERENCES RegisteredGroup(gid),
PRIMARY KEY(id, eid, gid));



--- THIS TRIGGER WORKS: a person who creates an event is automatically RSVP'ed to it
CREATE FUNCTION TF_RSVPToOwnEvent() RETURNS TRIGGER AS $$
  BEGIN
    INSERT INTO RSVPto VALUES(NEW.id, NEW.eid, NEW.gid);
    RETURN NEW;
  END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER TG_RSVPToOwnEvent 
	AFTER INSERT ON AllEvents
	FOR EACH ROW
	EXECUTE PROCEDURE TF_RSVPToOwnEvent();
  
  
--- THIS TRIGGER WORKS: Must be member of a group to RSVP to an event in it
CREATE FUNCTION TF_MustBeMemberToRSVP() RETURNS TRIGGER AS $$
		BEGIN
			IF NOT EXISTS (SELECT id, gid FROM isMemberOf
                    WHERE id = NEW.id
                    AND gid = NEW.gid)
 				THEN RAISE EXCEPTION 'You have to be a member of the group to RSVP to an event';
 			END IF;
      RETURN NEW;
		END;
$$ LANGUAGE plpgsql;

/* Front end design makes this obselete! 
CREATE TRIGGER TG_MustBeMemberToRSVP
	BEFORE INSERT ON RSVPto
	FOR EACH ROW
	EXECUTE PROCEDURE TF_MustBeMemberToRSVP();
*/

--- THIS TRIGGER WORKS: Only registered users can join a group
CREATE FUNCTION TF_MustBeMemberToCreateEvent() RETURNS TRIGGER AS $$
		BEGIN
			IF NOT EXISTS (SELECT id, gid FROM isMemberOf
                    WHERE id = NEW.id
                    AND gid = NEW.gid)
 				THEN RAISE EXCEPTION 'You have to be a member of the group to create an event';
 			END IF;
      RETURN NEW;
		END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER TG_CreateEventWhenNotInGroup
	BEFORE INSERT ON AllEvents
	FOR EACH ROW
	EXECUTE PROCEDURE TF_MustBeMemberToCreateEvent();

-- --- When a membership record is deleted, check if it's the last membership record of a group; if so, delete the group and all events associated with it.
-- CREATE FUNCTION TF_Delete_Group_After_Last_Member_Left() RETURNS TRIGGER AS $$
-- 		BEGIN
-- 			IF NOT EXISTS (SELECT id, gid FROM isMemberOf
--                     WHERE id = OLD.id
--                     AND gid = OLD.gid)
--  				THEN RAISE EXCEPTION 'The last member has just been deleted';
--  			END IF;
--       RETURN OLD;
-- 		END;
-- $$ LANGUAGE plpgsql;

-- CREATE TRIGGER TG_Delete_Group_After_Last_Member_Left
-- 	AFTER DELETE ON isMemberOf
--   FOR EACH ROW
--   EXECUTE PROCEDURE TF_Delete_Group_After_Last_Member_Left();

--- WHEN EVENT DELETED UNRSVP EVERYONE
CREATE FUNCTION TF_whenEventDeleted() RETURNS TRIGGER AS $$
		BEGIN
			IF EXISTS(SELECT eid FROM RSVPto WHERE eid = OLD.eid)
      	THEN DELETE FROM RSVPto WHERE (SELECT * FROM RSVPto WHERE eid = OLD.eid);
			END IF;
			RETURN NULL;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER TG_whenEventDeleted
	AFTER DELETE ON AllEvents
  --a delete of all events has row: eid | gid | id
	FOR EACH ROW
	EXECUTE PROCEDURE TF_whenEventDeleted();

--- When a membership record is deleted, check if it's the last membership record of a group; if so, delete the group and all events associated with it.  
  CREATE FUNCTION TF_Delete_Group_After_Last_Member_Left() RETURNS TRIGGER AS $$
		BEGIN
			IF NOT EXISTS (SELECT id FROM isMemberOf WHERE gid = OLD.gid) THEN 
				DELETE FROM RegisteredGroup WHERE (gid = OLD.gid);
				DELETE FROM RSVPto WHERE (gid = OLD.gid);
				DELETE FROM isMemberOf WHERE (gid = OLD.gid);
				DELETE FROM AllEvents WHERE (gid = OLD.gid);
 			END IF;
      RETURN OLD;
		END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER TG_Delete_Group_After_Last_Member_Left
	AFTER DELETE ON isMemberOf
	FOR EACH ROW
  	EXECUTE PROCEDURE TF_Delete_Group_After_Last_Member_Left();
  
  
  
  
  
