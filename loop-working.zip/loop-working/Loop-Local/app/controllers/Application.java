package controllers;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Map;
import java.util.ArrayList;
import javax.inject.Inject;

import play.*;
import play.mvc.*;
import play.data.*;

import views.html.*;

import models.LoopDB;

public class Application extends Controller {
    public String currentUserId;

    @Inject
    private FormFactory formFactory;
    @Inject
    private models.LoopDB LoopDB;

    public Result login() throws SQLException {
        return ok(login.render());
    }

    public Result authenticate() throws SQLException {
        Map<String, String> data = formFactory.form().bindFromRequest().data();
        String name = data.get("username");
        String pass = data.get("password");
        if (name == null || pass == null) {
            return ok(error.render("Bad request"));
        }

        boolean valid = LoopDB.authenticate(name, pass);
        if (!valid) {
            return ok(error.render("Incorrect username or password"));
        }

        session().clear();
        session("username", name);

        currentUserId = name;
        return redirect(routes.Application.index());
    }

    public Result index() throws SQLException {
        return ok(index.render(LoopDB.getRSVPEvents(currentUserId), LoopDB.getAllEvents(currentUserId), LoopDB.getNameOfUser(currentUserId), LoopDB.getUserGroups(currentUserId)));
    }

    public Result filter(String gid) throws SQLException {
        ArrayList<LoopDB.EventInfo> currRSVP = LoopDB.getRSVPEvents(currentUserId);
        ArrayList<LoopDB.EventInfo> newRSVP = new ArrayList<LoopDB.EventInfo>();
        for (LoopDB.EventInfo event : currRSVP){
            if(event.gid.equals(gid)) {
                newRSVP.add(event);
            }
        }

        ArrayList<LoopDB.EventInfo> currAll = LoopDB.getAllEvents(currentUserId);
        ArrayList<LoopDB.EventInfo> newAll = new ArrayList<LoopDB.EventInfo>();

        for (LoopDB.EventInfo event : currAll){
            if(event.gid.equals(gid)) {
                newAll.add(event);
            }
        }

        return ok(index.render(newRSVP, newAll, LoopDB.getNameOfUser(currentUserId), LoopDB.getUserGroups(currentUserId)));
    }

    public Result viewEvent(String eid) throws SQLException {
        LoopDB.EventInfo eventInfo = LoopDB.getEventInfo(eid);
        boolean isCreator = eventInfo.id.equals(currentUserId);
        return ok(eventDetails.render(eventInfo, LoopDB.getAttendees(eid), isCreator));
    }

    public Result clickRSVP(String eid) throws SQLException {
        boolean isRSVP = LoopDB.isRSVP(eid, currentUserId);
        if (isRSVP == true) {
            LoopDB.unRSVP(eid, currentUserId);
        } else if (isRSVP == false) {
            LoopDB.doRSVP(eid, currentUserId);
        }

        return redirect(routes.Application.index());

    }

    public Result join() throws SQLException {
        return ok(join.render());
    }

    public Result joinGroup() throws SQLException {
        Map<String, String> data = formFactory.form().bindFromRequest().data();
        String gid = data.get("groupid");
        LoopDB.addNewUserGroup(gid, currentUserId);
        return redirect(routes.Application.index());
    }

    public Result startEvent() throws SQLException {
        return ok(createevent.render(LoopDB.getUserGroups(currentUserId)));
    }

    public Result createEvent() throws SQLException {
        Map<String, String> data = formFactory.form().bindFromRequest().data();
        String name = data.get("eName");
        String loc = data.get("eLocation");
        String date = data.get("eDate");
        String start = data.get("eStart");
        String end = data.get("eEnd");
        String cost = data.get("eCost");
        String desc = data.get("eDescription");
        String gid = data.get("eGroup");


        if (name == null || loc == null ||
                name.compareTo("") == 0 || loc.compareTo("") == 0 ||
                name.compareTo("What are you doing?") == 0 || loc.compareTo("Where is it?") == 0 ||
                date == null || start == null || end == null ||
                date.compareTo("") == 0 || start.compareTo("") == 0 || end.compareTo("") == 0 ||
                gid.compareTo("") == 0 ||
                cost == null || desc == null ||
                desc.compareTo("") == 0) {
            return ok(eventError.render("All fields must be filled out to create a new event"));
        }

        //2222-04-04 03:03 date time

        //loopdb call
        //LoopDB.addNewUserGroup(gid, currentUserId);
        //rsvp call

        //String gid, String id, String eventName, String eventLocation,
        //                            String eventDate, String eventStartTime, String eventEndTime, Double eventCost
        LoopDB.createEvent(gid, currentUserId, name, loc, date, start, end, cost, desc);
        return redirect(routes.Application.index());
    }

    public Result startEdit(String eid) throws SQLException {
        LoopDB.EventInfo eventInfo = LoopDB.getEventInfo(eid);
        return ok(editevent.render(eventInfo));
    }


    public Result editEvent() throws SQLException {
        Map<String, String> data = formFactory.form().bindFromRequest().data();
        String eid = data.get("eid");
        String gid = data.get("gid");
        String id = data.get("id");
        String name = data.get("eName");
        String loc = data.get("eLocation");
        String date = data.get("eDate");
        String start = data.get("eStart");
        String end = data.get("eEnd");
        String cost = data.get("eCost");
        String desc = data.get("eDescription");

        if (eid == null || gid == null || id == null ||
                eid.compareTo("") == 0 || gid.compareTo("") == 0 || id.compareTo("") == 0 ||
                name == null || loc == null ||
                name.compareTo("") == 0 || loc.compareTo("") == 0 ||
                name.compareTo("What are you doing?") == 0 || loc.compareTo("Where is it?") == 0 ||
                date == null || start == null || end == null ||
                date.compareTo("") == 0 || start.compareTo("") == 0 || end.compareTo("") == 0 ||
                cost == null || desc == null ||
                desc.compareTo("") == 0) {
            return ok(editError.render("All fields must be filled out to edit this event", eid));
        }

        LoopDB.editEvent(eid, gid, id, name, loc, date, start, end, cost, desc);
        return redirect(routes.Application.index());
    }

    public Result delete(String eid) throws SQLException {
        LoopDB.deleteEvent(eid);
        return redirect(routes.Application.index());
    }

    public Result create() throws SQLException {
        return ok(createGroup.render());
    }

    public Result createGroup() throws SQLException {
        Map<String, String> data = formFactory.form().bindFromRequest().data();
        String name = data.get("name");
        LoopDB.createGroup(name, currentUserId);


        /*
        if (name == null || name.compareTo("") == 0 ||
                name.compareTo("E.g. CS316 Class") == 0) {
            LoopDB.createGroup(name, currentUserId);
            return redirect(routes.Application.index());
        }
        */


        //loopdb call
        //LoopDB.addNewUserGroup(gid, currentUserId);
        //membership call

        return redirect(routes.Application.index());
    }



}

