package models;

import play.db.*;
import javax.inject.*;
import java.math.BigDecimal;
import java.sql.*;
import javax.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

@Singleton
public class LoopDB {

    public static class Group {
        public String gid = null;
        public String name = null;

        public Group() {}

        public Group(String gid, String name){
            this.gid = gid;
            this.name = name;
        }

    }

    public static class EventInfo {
        public String eid = null;
        public String gid = null;
        public String id = null;
        public String name = null;
        public String location = null;
        public LocalDate date = null;
        public LocalTime startTime = null;
        public LocalTime endTime = null;
        public String description = null;
        public BigDecimal cost = null;


        public EventInfo() {
        }

        public EventInfo(String eid, String gid, String id, String name, String location,
                         LocalDate date, LocalTime startTime, LocalTime endTime, String description, BigDecimal cost) {
            this.eid = eid;
            this.gid = gid;
            this.id = id;
            this.name = name;
            this.location = location;
            this.date = date;
            this.startTime = startTime;
            this.endTime = endTime;
            this.description = description;
            this.cost = cost;
        }
    }

    private Database db;

    @Inject


    public LoopDB(Database db) {
        this.db = db;
    }

    public boolean authenticate(String username, String password) throws SQLException {
        Connection connection = null;
        boolean valid = false;
        try {
            connection = db.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT id, password FROM RegisteredUser WHERE id=? AND password=?");
            statement.setString(1, username);
            statement.setString(2, password);

            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                valid = true;
            }
            rs.close();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                }
            }
        }
        return valid;
    }

    public void addNewUserGroup(String gid, String uid) throws SQLException {
        Connection connection = null;

        try {
            connection = db.getConnection();

            PreparedStatement statement = connection
                    .prepareStatement("INSERT INTO isMemberOf VALUES(?,?)");
            statement.setString(1, uid);
            statement.setString(2, gid);
            statement.executeUpdate();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                }
            }
        }
    }

    public void doRSVP(String eid, String uid) throws SQLException{
        Connection connection = null;
        EventInfo event = getEventInfo(eid);

        try {
            connection = db.getConnection();

            PreparedStatement statement = connection
                    .prepareStatement("INSERT INTO RSVPto VALUES(?,?,?)");
            statement.setString(1, uid);
            statement.setString(2, event.eid);
            statement.setString(3, event.gid);
            statement.executeUpdate();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                }
            }

        }
    }


    public void unRSVP(String eid, String uid) throws SQLException {
        Connection connection = null;
        EventInfo event = getEventInfo(eid);

        try {
            connection = db.getConnection();

            PreparedStatement statement = connection
                    .prepareStatement("DELETE FROM RSVPto WHERE eid = ? AND id = ? AND gid = ?");
            statement.setString(1, event.eid);
            statement.setString(2, uid);
            statement.setString(3, event.gid);
            statement.executeUpdate();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                }
            }

        }

    }





    //check if an event is RSVPed to by a user, used to render active vs inactive RSVP button states in views
    public boolean isRSVP(String eidCheck, String uid) throws SQLException {
        Connection connection = null;
        ArrayList<String> RSVPeids = new ArrayList<String>();

        try {
            connection = db.getConnection();

            PreparedStatement statement = connection
                    .prepareStatement("SELECT eid FROM RSVPto WHERE RSVPto.id = ?");
            statement.setString(1, uid);
            ResultSet rs = statement.executeQuery();

            while (rs.next()) {
                String eid = rs.getString(1);
                RSVPeids.add(eid);
            }

            rs.close();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                }
            }

        }
        for (String eid: RSVPeids){
            if (eidCheck.equals(eid)) {
                return true;
            }
        }
        return false;
    }

    public EventInfo getEventInfo(String eid) throws SQLException {
        Connection connection = null;
        EventInfo event = new EventInfo();

        try {
            connection = db.getConnection();

            PreparedStatement statement = connection
                    .prepareStatement("SELECT * FROM AllEvents WHERE (AllEvents.eid = ?)");
            statement.setString(1, eid);
            ResultSet rs = statement.executeQuery();

            while (rs.next()) {

                String gid = rs.getString(2);

                String id = rs.getString(3);

                String name = rs.getString(4);

                String location = rs.getString(5);

                LocalDate date = rs.getObject(6, LocalDate.class);

                LocalTime startTime = rs.getObject(7, LocalTime.class);

                LocalTime endTime = rs.getObject(8, LocalTime.class);

                String description  = rs.getString(9);

                BigDecimal cost = rs.getBigDecimal(10);
                event = new EventInfo(eid, gid, id, name, location, date, startTime, endTime, description, cost);

            }

            rs.close();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                }
            }
        }

        return event;
    }

    public ArrayList<EventInfo> getAllEvents(String userID) throws SQLException {
        Connection connection = null;
        ArrayList<EventInfo> events = new ArrayList<EventInfo>();
        ArrayList<String> eids = new ArrayList<String>();
        ArrayList<String> gids = new ArrayList<String>();
        ArrayList<String> ids = new ArrayList<String>();
        ArrayList<String> names = new ArrayList<String>();
        ArrayList<String> locations = new ArrayList<String>();
        ArrayList<LocalDate> dates = new ArrayList<LocalDate>();
        ArrayList<LocalTime> startTimes = new ArrayList<LocalTime>();
        ArrayList<LocalTime> endTimes = new ArrayList<LocalTime>();
        ArrayList<String> descriptions = new ArrayList<String>();
        ArrayList<BigDecimal> costs = new ArrayList<BigDecimal>();

        try {
            connection = db.getConnection();
            PreparedStatement statement = connection
                    .prepareStatement("SELECT * FROM isMemberOf, AllEvents WHERE (isMemberOf.id = ? AND AllEvents.gid = isMemberOf.gid AND AllEvents.eid NOT IN (SELECT eid FROM RSVPTo WHERE id = ?))");
            statement.setString(1, userID);
            statement.setString(2, userID);

            ResultSet rs = statement.executeQuery();

            while (rs.next()) {
                String eid = rs.getString(3);
                eids.add(eid);

                String gid = rs.getString(2);
                gids.add(gid);

                String id = rs.getString(5);
                ids.add(id);

                String name = rs.getString(6);
                names.add(name);

                String location = rs.getString(7);
                locations.add(location);

                LocalDate date = rs.getObject(8, LocalDate.class);
                dates.add(date);

                LocalTime startTime = rs.getObject(9, LocalTime.class);
                startTimes.add(startTime);

                LocalTime endTime = rs.getObject(10, LocalTime.class);
                startTimes.add(endTime);

                String description  = rs.getString(11);
                descriptions.add(description);

                BigDecimal cost = rs.getBigDecimal(12);
                costs.add(cost);

                EventInfo event = new EventInfo(eid, gid, id, name, location, date, startTime, endTime, description, cost);
                events.add(event);

            }
            rs.close();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                }
            }
        }
        return events;
    }

    public ArrayList<EventInfo> getAllEventInfo(String uid) throws SQLException {
        return getAllEvents(uid);
    }

    public ArrayList<EventInfo> getRSVPEvents(String uid) throws SQLException {
        ArrayList<EventInfo> rsvpEvents = new ArrayList<EventInfo>();

        Connection connection = null;

        try {
            connection = db.getConnection();

            PreparedStatement statement = connection
                    .prepareStatement("SELECT eid FROM RSVPto WHERE id = ?");
            statement.setString(1, uid);
            ResultSet rs = statement.executeQuery();

            while (rs.next()) {
                String eid = rs.getString(1);
                EventInfo event = getEventInfo(eid);
                rsvpEvents.add(event);
            }
            rs.close();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                }
            }
        }
        return rsvpEvents;


    }

    public ArrayList<String> getAttendees(String eid) throws SQLException {
        Connection connection = null;
        ArrayList<String> attendees = new ArrayList<String>();

        try {
            connection = db.getConnection();

            PreparedStatement statement = connection
                    .prepareStatement("SELECT id FROM RSVPto WHERE RSVPto.eid = ?");
            statement.setString(1, eid);
            ResultSet rs = statement.executeQuery();

            while (rs.next()) {
                String attendee = getNameOfUser(rs.getString(1));
                attendees.add(attendee);
            }

            rs.close();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                }
            }

        }

        return attendees;
    }

    public String getNameOfUser(String uid) throws SQLException{
        Connection connection = null;
        String name = null;

        try {
            connection = db.getConnection();

            PreparedStatement statement = connection
                    .prepareStatement("SELECT name FROM RegisteredUser WHERE RegisteredUser.id = ?");
            statement.setString(1, uid);
            ResultSet rs = statement.executeQuery();

            while (rs.next()) {
                name = rs.getString(1);
            }

            rs.close();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                }
            }

        }

        return name;

    }

    public ArrayList<Group> getUserGroups(String uid) throws SQLException{
        Connection connection = null;
        ArrayList<Group> groups = new ArrayList<Group>();

        try {
            connection = db.getConnection();

            PreparedStatement statement = connection
                    .prepareStatement("SELECT DISTINCT * FROM isMemberOf, RegisteredGroup WHERE (isMemberOf.id = ? AND isMemberOf.gid = RegisteredGroup.gid)");
            statement.setString(1, uid);
            ResultSet rs = statement.executeQuery();

            while (rs.next()) {
                String gid = rs.getString(2);
                String name = rs.getString(4);

                Group group = new Group(gid, name);
                groups.add(group);
            }

            rs.close();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                }
            }

        }

        return groups;
    }


    private int getMaxID(String idColumnName, String table) throws SQLException {
        Connection connection = null;
        String maxIDString = null;
        try {
            connection = db.getConnection();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT " + idColumnName + " FROM " + table + " WHERE CAST("
                    + idColumnName + " AS INTEGER)>= ALL (SELECT CAST(" + idColumnName + " AS INTEGER)FROM " + table + ")");
            while (resultSet.next()) {
                maxIDString = resultSet.getString(1);
            }
            resultSet.close();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {

                }
            }
        }
        return Integer.parseInt(maxIDString);
    }
    public void createGroup(String groupName, String uid) throws SQLException {
        Connection connection = null;
        boolean oldAutoCommitState = true;

        try {
            connection = db.getConnection();

            oldAutoCommitState = connection.getAutoCommit();
            connection.setAutoCommit(false);

            int maxGroupId = getMaxID("gid", "RegisteredGroup");
            int firstValidId = maxGroupId + 1;
            String firstValidIdString = Integer.toString(firstValidId);

            PreparedStatement statement = connection.prepareStatement("INSERT INTO RegisteredGroup VALUES(?, ?)");
            statement.setString(1, firstValidIdString);
            statement.setString(2, groupName);
            statement.executeUpdate();
            statement.close();

            statement = connection
                    .prepareStatement("INSERT INTO isMemberOf VALUES(?,?)");
            statement.setString(1, uid);
            statement.setString(2, firstValidIdString);
            statement.executeUpdate();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.setAutoCommit(oldAutoCommitState);
                    connection.close();
                } catch (Exception e) {
                }
            }
        }
    }

    public void deleteEvent(String eid) throws SQLException {
        Connection connection = null;
        try {
            connection = db.getConnection();

            PreparedStatement statement = connection.prepareStatement("DELETE FROM RSVPto WHERE eid = ?");
            statement.setString(1, eid);
            statement.executeUpdate();
            statement.close();

            statement = connection.prepareStatement("DELETE FROM AllEvents WHERE eid = ?");
            statement.setString(1, eid);
            statement.executeUpdate();
            statement.close();

        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                }
            }

        }
    }

    public void editEvent(String eid, String gid, String id, String eventName, String eventLocation,
                          String eventDate, String eventStartTime, String eventEndTime, String eventCost, String eventDesc) throws SQLException{
        Connection connection = null;
        try{
            connection = db.getConnection();

            /*
            PreparedStatement statement = connection.prepareStatement("DELETE FROM AllEvents WHERE eid = ?");
            statement.setString(1, eid);
            statement.executeUpdate();
            statement.close();

             */

            LocalDate date = LocalDate.parse(eventDate);
            LocalTime startTime = LocalTime.parse(eventStartTime);
            LocalTime endTime = LocalTime.parse(eventEndTime);
            Float cost = new Float(eventCost);

            PreparedStatement statement = connection
                    .prepareStatement("UPDATE AllEvents SET eid= ?, gid = ?, id = ?, event_name = ?, event_location = ?, event_date = ?, event_start_time = ?, event_end_time = ?, event_description = ?, event_cost = ? WHERE eid = ? ");
            statement.setString(1, eid);
            statement.setString(2, gid);
            statement.setString(3, id);
            statement.setString(4, eventName);
            statement.setString(5, eventLocation);
            statement.setObject(6, date);
            statement.setObject(7, startTime);
            statement.setObject(8, endTime);
            statement.setString(9, eventDesc);
            statement.setBigDecimal(10, new BigDecimal(cost));
            statement.setString(11, eid);
            statement.executeUpdate();
            statement.close();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                }
            }
        }

    }

    public void createEvent(String gid, String id, String eventName, String eventLocation,
                            String eventDate, String eventStartTime, String eventEndTime, String eventCost, String eventDesc)
            throws SQLException {

        Connection connection = null;
        boolean oldAutoCommitState = true;

        try {
            connection = db.getConnection();
            connection.setAutoCommit(false);

            int maxEID = getMaxID("eid", "AllEvents") ;
            int firstValidEID = maxEID + 1;


            String firstValString = Integer.toString(firstValidEID);

            LocalDate date = LocalDate.parse(eventDate);
            LocalTime startTime = LocalTime.parse(eventStartTime);
            LocalTime endTime = LocalTime.parse(eventEndTime);
            Float cost = new Float(eventCost);

            //generate eventid = groupid+4digits
            //is do query to determine current eventid max then add
            // 1

            // update basic info:
            PreparedStatement statement = connection
                    .prepareStatement("INSERT INTO AllEvents VALUES(?,?,?,?,?,?,?,?,?,?)");
            statement.setString(1, firstValString);
            statement.setString(2, gid);
            statement.setString(3, id);
            statement.setString(4, eventName);
            statement.setString(5, eventLocation);
            statement.setObject(6, date);
            statement.setObject(7, startTime);
            statement.setObject(8, endTime);
            statement.setString(9, eventDesc);
            statement.setBigDecimal(10, new BigDecimal(cost));
            statement.executeUpdate();
            statement.close();


        }
        finally {
            if (connection != null) {
                try {
                    connection.setAutoCommit(oldAutoCommitState);
                    connection.close();
                } catch (Exception e) {
                }
            }
        }
    }


}
