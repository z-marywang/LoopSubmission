# Code Structure -------------------------------------------------------

Our main directory is named loop-working, which contains additional files needed for development. The Loop-Local sub-directory contains all actual application files.

Our code structure follows the Play template for the beers-db pretty exactly. The app directory holds the controllers, models, and view. There is a build.sbt file, conf directory for configuration, logs directory for logs, public directory for styling files, target directory, and loop-db directory that holds database set-up files.

In more details, the app has one controller file named Application.java that runs the app. There is also only one model named LoopDB.java that connects to the database for any needed queries. In view, the app has several form set ups for different actions, including creating groups and events, editing events, joining groups, throwing an error, and displaying the main page.

The conf files include an application.conf that connects to the local database with user permissions. The routes file contains all the route mappings used in the above controller and views.

# How to compile, set up, deploy ---------------------------------------

This project was developed on the course VM, so the first step would be to set up the course VM with vagrant and VirtualBox.

Then, set up the Postgres SQL database by navigating to loop-db. The steps are: create the database with created loop, create the tables by running psql -af loop create-table-base.sql, and load the tables by running psql -af loop load-table-new.sql. This has been simplified in the setup.sh file. For some reason, the load file does throw some errors with RSVPTo and constraints, but we found that those errors do not impact the actual result weirdly.

Next, we found it necessary to grant a user privileges for the loop tables to interact with them in the app, so we followed a tutorial to set up a new user named "tester" with a password "tester" that was granted all privileges on all tables within loop. This involved:

1. Navigate to Loop-Local folder while ssh'ed into vagrant
2. psql loop
3. CREATE USER tester WITH ENCRYPTED PASSWORD 'tester';
4. GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO tester;
5. GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO tester;

After that, you can navigate to Loop-Local (not the main loop-working directory) and enter the normal sbt and run commands. The app can then be accessed at localhost:9000/login. Please start at the login page.

# Limitations ----------------------------------------------------------

The main limitation of the current implementation is that it is local, so it cannot be deployed to the web as of right now. Our next step would be to host the database somewhere like on a Google Cloud VM or AWS so that it can be publicly connected to with a website.
